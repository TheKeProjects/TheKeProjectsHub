import tkinter as tk
from tkinter import ttk, messagebox
import requests
import os
import subprocess
from io import BytesIO
from PIL import Image, ImageTk
import threading
import webbrowser
import time
import sys
import json
import pygame
import tempfile
from pathlib import Path
import urllib.request
import urllib.error
import re

# ===== CONSTANTES Y CONFIGURACIÓN DE ACTUALIZACIONES =====
CONFIG_DIR = os.path.join(os.path.expanduser('~'), 'Documents', 'TheKeProjectsHub')
VERSION_FILE = os.path.join(CONFIG_DIR, 'hub_version.txt')
CHANGELOG_FILE = os.path.join(CONFIG_DIR, 'hub_changelog.txt')

# URLs para actualizaciones del hub
HUB_GITHUB_REPO = "https://raw.githubusercontent.com/TheKeProjects/TheKeProjectsHub/main/version.txt"
HUB_GITHUB_CHANGELOG = "https://raw.githubusercontent.com/TheKeProjects/TheKeProjectsHub/main/changelog.txt"
HUB_UPDATE_URL = "https://github.com/TheKeProjects/TheKeProjectsHub/releases/latest"
HUB_INSTALLER_URL = "https://github.com/TheKeProjects/TheKeProjectsHub/releases/latest/download/TheKeProjects_Setup.exe"

class GitHubAppInstaller:
    def __init__(self, root):
        self.root = root
        self.root.title("TheKeProjects")
        self.root.geometry("900x700")
        self.root.resizable(False, False)
        
        # Eliminar la barra de título
        self.root.overrideredirect(True)
        # Mantener siempre en primer plano
        self.root.attributes('-topmost', True)
        
        # Inicializar pygame mixer
        pygame.mixer.init()
        
        # Directorio para configuración
        self.app_data_dir = CONFIG_DIR
        os.makedirs(self.app_data_dir, exist_ok=True)
        self.settings_file = os.path.join(self.app_data_dir, "settings.json")
        
        # Cargar configuración
        self.settings = self.load_settings()
        
        # Configurar temas
        self.current_theme_name = self.settings.get("theme", "dark")
        self.theme_colors = self.get_theme_colors(self.current_theme_name)
        
        # Configuración de música
        self.music_enabled = self.settings.get("music_enabled", True)
        self.music_paused = self.settings.get("music_paused", False)
        self.volume_level = self.settings.get("volume", 0.03)
        pygame.mixer.music.set_volume(self.volume_level)
        
        # Variables de actualización
        self.update_available = False
        self.current_version = self.get_current_version()
        
        # Frame principal
        self.main_frame = tk.Frame(root, bg=self.theme_colors["bg_color"])
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Crear barra de título personalizada
        self.create_title_bar()
        
        # Vista actual (main o patchnotes)
        self.current_view = "main"
        self.current_app = None
        
        # Definir aplicaciones
        self.apps = [
            {
                "name": "InaPet",
                "repo": "TheKeProjects/InaPet",
                "icon_url": "https://raw.githubusercontent.com/TheKeProjects/InaPet/main/icon.ico",
                "filename": "InaPet_Setup.exe",
                "version_url": "https://raw.githubusercontent.com/TheKeProjects/InaPet/main/version.txt",
                "changelog_url": "https://raw.githubusercontent.com/TheKeProjects/InaPet/main/changelog.txt",
                "version": "Cargando...",
                "changelog": "Cargando notas de versión...",
                "release_url": None
            },
            {
                "name": "PassManager",
                "repo": "TheKeProjects/PassManager",
                "icon_url": "https://raw.githubusercontent.com/TheKeProjects/PassManager/main/icon.ico",
                "filename": "PassManager_Setup.exe",
                "version_url": "https://raw.githubusercontent.com/TheKeProjects/PassManager/main/version.txt",
                "changelog_url": "https://raw.githubusercontent.com/TheKeProjects/PassManager/main/changelog.txt",
                "version": "Cargando...",
                "changelog": "Cargando notas de versión...",
                "release_url": None
            },
            {
                "name": "Custom-Cursor",
                "repo": "TheKeProjects/Custom-Cursor",
                "icon_url": "https://raw.githubusercontent.com/TheKeProjects/Custom-Cursor/main/icon.ico",
                "filename": "Custom-Cursor_Setup.exe",
                "version_url": "https://raw.githubusercontent.com/TheKeProjects/Custom-Cursor/main/version.txt",
                "changelog_url": "https://raw.githubusercontent.com/TheKeProjects/Custom-Cursor/main/changelog.txt",
                "version": "Cargando...",
                "changelog": "Cargando notas de versión...",
                "release_url": None
            },
            {
                "name": "AutoArchiver",
                "repo": "TheKeProjects/AutoArchiver",
                "icon_url": "https://raw.githubusercontent.com/TheKeProjects/AutoArchiver/main/icon.ico",
                "filename": "AutoArchiver_Setup.exe",
                "version_url": "https://raw.githubusercontent.com/TheKeProjects/AutoArchiver/main/version.txt",
                "changelog_url": "https://raw.githubusercontent.com/TheKeProjects/AutoArchiver/main/changelog.txt",
                "version": "Cargando...",
                "changelog": "Cargando notas de versión...",
                "release_url": None
            }
        ]
        
        # Crear vistas
        self.create_main_view()
        self.create_patchnotes_view()
        
        # Mostrar vista principal inicialmente
        self.show_main_view()
        
        # Posicionar la ventana en el centro de la pantalla
        self.center_window()
        
        # Bind para mover la ventana
        self.title_bar.bind("<ButtonPress-1>", self.start_move)
        self.title_bar.bind("<ButtonRelease-1>", self.stop_move)
        self.title_bar.bind("<B1-Motion>", self.on_move)
        
        # Iniciar música si corresponde
        self.init_music()
        
        # Verificar actualizaciones en segundo plano
        self.check_for_updates_in_background()
        
        # Mostrar cambios si es una nueva instalación
        self.show_update_changes_if_needed()
        
        # Configurar el protocolo de cierre
        self.root.protocol("WM_DELETE_WINDOW", self.clean_exit)
    
    # ===== MÉTODOS DE ACTUALIZACIÓN =====
    def get_current_version(self):
        """Obtiene la versión actual de la aplicación"""
        try:
            if os.path.exists(VERSION_FILE):
                with open(VERSION_FILE, "r") as f:
                    return f.read().strip()
        except:
            pass
        return "1.0.1"  # Versión inicial

    def save_current_version(self, version):
        """Guarda la versión actual en un archivo"""
        try:
            with open(VERSION_FILE, "w") as f:
                f.write(version)
        except:
            pass

    def check_for_updates_in_background(self):
        """Verifica actualizaciones en segundo plano"""
        threading.Thread(target=self.check_updates, daemon=True).start()

    def check_updates(self, show_message=False):
        """Verifica si hay actualizaciones disponibles en GitHub"""
        try:
            current_version = self.get_current_version()
            response = urllib.request.urlopen(HUB_GITHUB_REPO, timeout=5)
            remote_version = response.read().decode().strip()
            
            if remote_version != current_version:
                self.update_available = True
                if show_message:
                    self.show_update_prompt(remote_version, current_version)
                self.root.after(0, self.update_ui_for_updates)
            else:
                self.update_available = False
                if show_message:
                    messagebox.showinfo("Actualización", "Ya tienes la última versión.")
                self.root.after(0, self.update_ui_for_updates)
        except Exception as e:
            self.update_available = False
            if show_message:
                messagebox.showerror("Error", f"No se pudo verificar actualizaciones: {str(e)}")
            self.root.after(0, self.update_ui_for_updates)

    def update_ui_for_updates(self):
        """Actualiza la UI para mostrar/ocultar el botón de actualización"""
        if hasattr(self, 'update_btn'):
            if self.update_available:
                self.update_btn.pack(side=tk.LEFT, padx=2)
            else:
                self.update_btn.pack_forget()

    def download_changelog(self):
        """Descarga el changelog desde GitHub"""
        try:
            with urllib.request.urlopen(HUB_GITHUB_CHANGELOG, timeout=5) as response:
                return response.read().decode('utf-8')
        except Exception as e:
            print(f"Error al descargar changelog: {e}")
            return "No se pudieron obtener las notas de la versión."

    def show_update_prompt(self, remote_version, current_version):
        """Muestra un diálogo informando sobre la nueva versión"""
        changelog = self.download_changelog()
        message = f"¡Hay una nueva versión disponible!\n\n" \
                  f"Versión actual: {current_version}\n" \
                  f"Nueva versión: {remote_version}\n\n" \
                  f"Notas de la versión:\n{changelog}\n\n" \
                  "¿Deseas actualizar ahora?"
        
        if messagebox.askyesno("Actualización disponible", message):
            self.perform_update(remote_version)

    def perform_update(self, remote_version):
        """Realiza el proceso de actualización"""
        try:
            changelog = self.download_changelog()
            with open(CHANGELOG_FILE, "w", encoding="utf-8") as f:
                f.write(remote_version + "\n\n" + changelog)
        except:
            pass
        
        if sys.platform == "win32":
            try:
                temp_dir = tempfile.gettempdir()
                installer_path = os.path.join(temp_dir, "TheKeProjectsHub_Updater.exe")
                
                with urllib.request.urlopen(HUB_INSTALLER_URL) as response:
                    with open(installer_path, 'wb') as out_file:
                        out_file.write(response.read())
                
                subprocess.Popen([installer_path, "/SILENT"])
                self.clean_exit()
            except Exception as e:
                messagebox.showerror("Error de actualización", 
                                    f"No se pudo descargar el actualizador: {str(e)}\n"
                                    "Por favor, actualiza manualmente desde GitHub.")
                webbrowser.open(HUB_UPDATE_URL)
        else:
            webbrowser.open(HUB_UPDATE_URL)
            messagebox.showinfo("Actualización manual", "Por favor, descarga la última versión desde el navegador.")

    def show_update_changes_if_needed(self):
        """Muestra los cambios si se acaba de actualizar"""
        if os.path.exists(CHANGELOG_FILE):
            try:
                with open(CHANGELOG_FILE, "r", encoding="utf-8") as f:
                    content = f.read()
                    parts = content.split("\n\n", 1)
                    version = parts[0]
                    changelog = parts[1] if len(parts) > 1 else "No hay notas disponibles."
                
                messagebox.showinfo(f"Notas de la versión {version}", changelog)
                os.remove(CHANGELOG_FILE)
            except Exception as e:
                print(f"Error al mostrar cambios de actualización: {e}")

    def check_updates_ui(self):
        """Verifica actualizaciones desde la interfaz de usuario"""
        self.check_updates(show_message=True)

    # ===== FIN MÉTODOS DE ACTUALIZACIÓN =====
    
    def get_theme_colors(self, theme_name):
        """Devuelve los colores para un tema específico"""
        themes = {
            "default": {
                "type": "gradient",
                "colors": [(255, 182, 193), (230, 200, 255), (255, 255, 255)],
                "button_bg": "#A7377C",
                "button_fg": "white",
                "label_fg": "black",
                "entry_bg": "white",
                "entry_fg": "black",
                "bg_color": "#FFFFFF",
                "action_btn_bg": "#DDDDDD",
                "action_btn_fg": "black",
                "delete_btn_bg": "#FF5555",
                "music": None,
                "history_bg": "#FFFFFF",
                "history_fg": "black",
                "title_bg": "#f0f0f0",
                "frame_border": "#cccccc",
                "scrollbar_bg": "#f0f0f0",
                "scrollbar_trough": "#ffffff",
                "canvas_bg": "#ffffff",
                "hover": "#f0f8ff",
                "icon_hover": "#e6f7ff",
                "title_fg": "black",
                "status_bg": "#f0f0f0",
                "status_fg": "black"
            },
            "dark": {
                "type": "solid",
                "color": (40, 40, 40),
                "button_bg": "#333333",
                "button_fg": "#CCCCCC",
                "label_fg": "#FFFFFF",
                "entry_bg": "#222222",
                "entry_fg": "#FFFFFF",
                "bg_color": "#282828",
                "action_btn_bg": "#555555",
                "action_btn_fg": "#CCCCCC",
                "delete_btn_bg": "#992222",
                "music": None,
                "history_bg": "#222222",
                "history_fg": "#FFFFFF",
                "title_bg": "#1f1f1f",
                "frame_border": "#444444",
                "scrollbar_bg": "#3b3b3b",
                "scrollbar_trough": "#2b2b2b",
                "canvas_bg": "#2b2b2b",
                "hover": "#3b3b3b",
                "icon_hover": "#4b4b4b",
                "title_fg": "#FFFFFF",
                "status_bg": "#1f1f1f",
                "status_fg": "#CCCCCC"
            },
            "purple": {
                "type": "gradient",
                "colors": [(150, 50, 200), (100, 0, 150), (70, 0, 100)],
                "button_bg": "#7D3C98",
                "button_fg": "white",
                "label_fg": "white",
                "entry_bg": "#4A235A",
                "entry_fg": "white",
                "bg_color": "#4A235A",
                "action_btn_bg": "#5D3C71",
                "action_btn_fg": "white",
                "delete_btn_bg": "#992266",
                "music": None,
                "history_bg": "#4A235A",
                "history_fg": "white",
                "title_bg": "#3A135A",
                "frame_border": "#5A357A",
                "scrollbar_bg": "#5D3C71",
                "scrollbar_trough": "#4A235A",
                "canvas_bg": "#4A235A",
                "hover": "#5D3C71",
                "icon_hover": "#6D4C81",
                "title_fg": "white",
                "status_bg": "#3A135A",
                "status_fg": "white"
            },
            "ultrakill": {
                "type": "gradient",
                "colors": [(200, 0, 0), (0, 0, 0), (100, 0, 0)],
                "button_bg": "#8B0000",
                "button_fg": "#FFD700",
                "label_fg": "#FF4500",
                "entry_bg": "#222222",
                "entry_fg": "#FF0000",
                "bg_color": "#111111",
                "action_btn_bg": "#450000",
                "action_btn_fg": "#FFA500",
                "delete_btn_bg": "#B22222",
                "music": "ultrakill_theme.mp3",
                "history_bg": "#111111",
                "history_fg": "#FF0000",
                "title_bg": "#200000",
                "frame_border": "#444444",
                "scrollbar_bg": "#450000",
                "scrollbar_trough": "#111111",
                "canvas_bg": "#111111",
                "hover": "#450000",
                "icon_hover": "#650000",
                "title_fg": "#FF4500",
                "status_bg": "#200000",
                "status_fg": "#FF4500"
            },
            "sonic": {
                "type": "gradient",
                "colors": [(0, 100, 255), (0, 200, 255), (0, 50, 150)],
                "button_bg": "#0066CC",
                "button_fg": "#FFCC00",
                "label_fg": "#0066CC",
                "entry_bg": "#99CCFF",
                "entry_fg": "black",
                "bg_color": "#99CCFF",
                "action_btn_bg": "#3399FF",
                "action_btn_fg": "#003366",
                "delete_btn_bg": "#FF6600",
                "music": "sonic_theme.mp3",
                "history_bg": "#99CCFF",
                "history_fg": "#003366",
                "title_bg": "#0077DD",
                "frame_border": "#66AAFF",
                "scrollbar_bg": "#3399FF",
                "scrollbar_trough": "#99CCFF",
                "canvas_bg": "#99CCFF",
                "hover": "#BBEEFF",
                "icon_hover": "#DDF7FF",
                "title_fg": "#003366",
                "status_bg": "#0077DD",
                "status_fg": "#003366"
            },
            "zelda": {
                "type": "gradient",
                "colors": [(0, 100, 0), (150, 120, 50), (70, 40, 10)],
                "button_bg": "#4B692F",
                "button_fg": "#F5E296",
                "label_fg": "#4B692F",
                "entry_bg": "#E6D3A7",
                "entry_fg": "black",
                "bg_color": "#E6D3A7",
                "action_btn_bg": "#8A9A5B",
                "action_btn_fg": "#2C4001",
                "delete_btn_bg": "#8B4513",
                "music": "zelda_theme.mp3",
                "history_bg": "#E6D3A7",
                "history_fg": "#2C4001",
                "title_bg": "#5B793F",
                "frame_border": "#C6B397",
                "scrollbar_bg": "#8A9A5B",
                "scrollbar_trough": "#E6D3A7",
                "canvas_bg": "#E6D3A7",
                "hover": "#F6E9C7",
                "icon_hover": "#FFF9E7",
                "title_fg": "#2C4001",
                "status_bg": "#5B793F",
                "status_fg": "#2C4001"
            },
            "mario": {
                "type": "gradient",
                "colors": [(200, 0, 0), (0, 0, 200), (255, 200, 0)],
                "button_bg": "#E52521",
                "button_fg": "#FBD000",
                "label_fg": "#E52521",
                "entry_bg": "#6BACE4",
                "entry_fg": "black",
                "bg_color": "#6BACE4",
                "action_btn_bg": "#FF6B6B",
                "action_btn_fg": "#8B0000",
                "delete_btn_bg": "#FF4500",
                "music": "mario_theme.mp3",
                "history_bg": "#6BACE4",
                "history_fg": "#8B0000",
                "title_bg": "#E52521",  # Cambiado a rojo más brillante
                "frame_border": "#8BC4F4",
                "scrollbar_bg": "#FF6B6B",
                "scrollbar_trough": "#6BACE4",
                "canvas_bg": "#6BACE4",
                "hover": "#9BCDF4",
                "icon_hover": "#BBE5FF",
                "title_fg": "#FBD000",  # Cambiado a amarillo para mejor contraste
                "status_bg": "#E52521",
                "status_fg": "#FBD000"  # Cambiado a amarillo para mejor contraste
            },
            "pokemon": {
                "type": "gradient",
                "colors": [(255, 203, 5), (61, 125, 202), (255, 0, 0)],
                "button_bg": "#FFCB05",
                "button_fg": "#3D7DCA",
                "label_fg": "#3D7DCA",
                "entry_bg": "#FFCB05",
                "entry_fg": "black",
                "bg_color": "#FFCB05",
                "action_btn_bg": "#3D7DCA",
                "action_btn_fg": "#FFCB05",
                "delete_btn_bg": "#FF0000",
                "music": "pokemon_theme.mp3",
                "history_bg": "#FFCB05",
                "history_fg": "#3D7DCA",
                "title_bg": "#EFBB00",
                "frame_border": "#FFDB35",
                "scrollbar_bg": "#3D7DCA",
                "scrollbar_trough": "#FFCB05",
                "canvas_bg": "#FFCB05",
                "hover": "#FFDB35",
                "icon_hover": "#FFEB65",
                "title_fg": "#3D7DCA",
                "status_bg": "#EFBB00",
                "status_fg": "#3D7DCA"
            },
            "minecraft": {
                "type": "gradient",
                "colors": [(0, 150, 0), (100, 50, 0), (0, 100, 150)],
                "button_bg": "#00A651",
                "button_fg": "#8B4513",
                "label_fg": "#8B4513",  # Cambiado a marrón para mejor contraste
                "entry_bg": "#D2B48C",
                "entry_fg": "black",
                "bg_color": "#D2B48C",
                "action_btn_bg": "#8B4513",
                "action_btn_fg": "#00A651",
                "delete_btn_bg": "#CD5C5C",
                "music": "minecraft_theme.mp3",
                "history_bg": "#D2B48C",
                "history_fg": "#8B4513",  # Cambiado a marrón para mejor contraste
                "title_bg": "#009641",
                "frame_border": "#E2C49C",
                "scrollbar_bg": "#8B4513",
                "scrollbar_trough": "#D2B48C",
                "canvas_bg": "#D2B48C",
                "hover": "#E2C49C",
                "icon_hover": "#F2D4AC",
                "title_fg": "#8B4513",  # Cambiado a marrón para mejor contraste
                "status_bg": "#009641",
                "status_fg": "#8B4513"  # Cambiado a marrón para mejor contraste
            }
        }
        return themes.get(theme_name, themes["dark"])
    
    def load_settings(self):
        settings = {}
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, "r") as f:
                    settings = json.load(f)
            except:
                pass
        return settings
    
    def save_settings(self):
        with open(self.settings_file, "w") as f:
            json.dump(self.settings, f)
    
    def init_music(self):
        pygame.mixer.music.set_volume(self.volume_level)
        if self.music_enabled:
            self.play_theme_music()
            if self.music_paused:
                self.pause_music()
    
    def play_theme_music(self):
        music_file = self.theme_colors.get("music")
        if not music_file:
            return
        
        # Buscar el archivo de música en varios directorios
        music_dirs = [
            os.path.dirname(os.path.abspath(__file__)),
            self.app_data_dir,
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "musica")
        ]
        
        music_path = None
        for dir_path in music_dirs:
            test_path = os.path.join(dir_path, music_file)
            if os.path.exists(test_path):
                music_path = test_path
                break
        
        if music_path:
            try:
                pygame.mixer.music.set_volume(self.volume_level)
                pygame.mixer.music.load(music_path)
                pygame.mixer.music.play(-1)
                self.music_paused = False
                self.settings["music_paused"] = False
                self.save_settings()
            except Exception as e:
                print(f"Error al reproducir música: {e}")
    
    def pause_music(self):
        if pygame.mixer.music.get_busy() and not self.music_paused:
            pygame.mixer.music.pause()
            self.music_paused = True
            self.settings["music_paused"] = True
            self.save_settings()
    
    def unpause_music(self):
        if self.music_paused and self.music_enabled:
            pygame.mixer.music.unpause()
            self.music_paused = False
            self.settings["music_paused"] = False
            self.save_settings()
    
    def stop_music(self):
        if pygame.mixer.music.get_busy() or self.music_paused:
            pygame.mixer.music.stop()
            self.music_paused = False
            self.settings["music_paused"] = False
            self.save_settings()
    
    def toggle_music(self):
        if self.music_enabled:
            if self.music_paused:
                self.unpause_music()
            else:
                self.pause_music()
    
    def set_volume(self, volume):
        self.volume_level = volume
        pygame.mixer.music.set_volume(volume)
        self.settings["volume"] = volume
        self.save_settings()
    
    def show_volume_control(self):
        win = tk.Toplevel(self.root)
        win.title("Control de Audio")
        win.geometry("300x150")
        win.transient(self.root)
        win.grab_set()
        win.config(bg=self.theme_colors["bg_color"])
        
        control_frame = tk.Frame(win, bg=self.theme_colors["bg_color"])
        control_frame.pack(pady=10, fill="x", padx=20)
        
        btn_frame = tk.Frame(control_frame, bg=self.theme_colors["bg_color"])
        btn_frame.pack(fill="x", pady=5)
        
        toggle_text = "⏸️ Pausar" if not self.music_paused else "▶️ Reanudar"
        toggle_btn = tk.Button(
            btn_frame, 
            text=toggle_text,
            command=self.toggle_music,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        )
        toggle_btn.pack(side="left", padx=5)
        
        stop_btn = tk.Button(
            btn_frame, 
            text="⏹️ Detener",
            command=self.stop_music,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        )
        stop_btn.pack(side="left", padx=5)
        
        volume_frame = tk.Frame(control_frame, bg=self.theme_colors["bg_color"])
        volume_frame.pack(fill="x", pady=5)
        
        volume_var = tk.DoubleVar(value=self.volume_level)
        volume_slider = tk.Scale(
            volume_frame,
            from_=0.0,
            to=1.0,
            resolution=0.01,
            orient="horizontal",
            variable=volume_var,
            command=lambda v: self.set_volume(float(v)),
            length=250,
            bg=self.theme_colors["bg_color"],
            fg=self.theme_colors["label_fg"],
            highlightthickness=0
        )
        volume_slider.pack()
        
        vol_label = tk.Label(
            volume_frame, 
            text=f"Volumen: {int(self.volume_level*100)}%",
            bg=self.theme_colors["bg_color"],
            fg=self.theme_colors["label_fg"]
        )
        vol_label.pack(pady=5)
        
        def update_label(*args):
            vol_label.config(text=f"Volumen: {int(volume_var.get()*100)}%")
        volume_var.trace_add("write", update_label)
    
    def show_theme_menu(self):
        """Muestra el menú de selección de temas"""
        menu = tk.Menu(self.root, tearoff=0, 
                      bg=self.theme_colors["entry_bg"], 
                      fg=self.theme_colors["entry_fg"])
        
        menu.add_command(label="Por defecto", command=lambda: self.change_theme("default"))
        menu.add_command(label="Modo Oscuro", command=lambda: self.change_theme("dark"))
        menu.add_command(label="Morado", command=lambda: self.change_theme("purple"))
        menu.add_separator()
        menu.add_command(label="Ultrakill", command=lambda: self.change_theme("ultrakill"))
        menu.add_command(label="Sonic", command=lambda: self.change_theme("sonic"))
        menu.add_command(label="Zelda", command=lambda: self.change_theme("zelda"))
        menu.add_command(label="Mario", command=lambda: self.change_theme("mario"))
        menu.add_command(label="Pokémon", command=lambda: self.change_theme("pokemon"))
        menu.add_command(label="Minecraft", command=lambda: self.change_theme("minecraft"))
        
        # Mostrar el menú cerca del botón
        btn_x = self.theme_btn.winfo_rootx()
        btn_y = self.theme_btn.winfo_rooty() + self.theme_btn.winfo_height()
        menu.post(btn_x, btn_y)
    
    def change_theme(self, theme_name):
        self.current_theme_name = theme_name
        self.theme_colors = self.get_theme_colors(theme_name)
        self.settings["theme"] = theme_name
        self.save_settings()
        
        # Actualizar música
        new_music = self.theme_colors.get("music")
        if new_music and self.music_enabled:
            self.stop_music()
            self.play_theme_music()
        else:
            self.stop_music()
        
        # Recrear las vistas para aplicar el nuevo tema completamente
        self.recreate_views()
    
    def recreate_views(self):
        """Recrea todas las vistas para aplicar el nuevo tema"""
        # Destruir vistas existentes
        self.main_view.destroy()
        self.patchnotes_view.destroy()
        
        # Recrear vistas
        self.create_main_view()
        self.create_patchnotes_view()
        
        # Mostrar la vista actual
        if self.current_view == "main":
            self.show_main_view()
        else:
            self.show_patchnotes_view()
            
        # Aplicar el tema a la barra de título
        self.apply_title_bar_theme()
    
    def apply_title_bar_theme(self):
        """Aplica el tema actual a la barra de título"""
        self.title_bar.config(bg=self.theme_colors["title_bg"])
        for widget in self.title_bar.winfo_children():
            if isinstance(widget, tk.Label):
                widget.config(bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"])
            elif isinstance(widget, tk.Frame):
                widget.config(bg=self.theme_colors["title_bg"])
                for btn in widget.winfo_children():
                    btn.config(bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"],
                              activebackground=self.theme_colors["hover"])
        
        # Configurar hover para botones
        self.close_btn.config(bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"])
        self.close_btn.bind("<Enter>", lambda e: self.close_btn.config(bg="#ff0000", fg="white"))
        self.close_btn.bind("<Leave>", lambda e: self.close_btn.config(bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"]))
        
        self.audio_btn.config(bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"],
                             activebackground=self.theme_colors["hover"])
        self.audio_btn.bind("<Enter>", lambda e: self.audio_btn.config(bg=self.theme_colors["hover"]))
        self.audio_btn.bind("<Leave>", lambda e: self.audio_btn.config(bg=self.theme_colors["title_bg"]))
        
        self.theme_btn.config(bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"],
                             activebackground=self.theme_colors["hover"])
        self.theme_btn.bind("<Enter>", lambda e: self.theme_btn.config(bg=self.theme_colors["hover"]))
        self.theme_btn.bind("<Leave>", lambda e: self.theme_btn.config(bg=self.theme_colors["title_bg"]))
        
        # Configurar botón de actualización si existe
        if hasattr(self, 'update_btn'):
            self.update_btn.config(bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"],
                                 activebackground=self.theme_colors["hover"])
            self.update_btn.bind("<Enter>", lambda e: self.update_btn.config(bg=self.theme_colors["hover"]))
            self.update_btn.bind("<Leave>", lambda e: self.update_btn.config(bg=self.theme_colors["title_bg"]))
    
    def clean_exit(self):
        """Cierra la aplicación completamente"""
        self.stop_music()
        pygame.mixer.quit()
        self.root.quit()
        self.root.destroy()
        sys.exit(0)
    
    def center_window(self):
        """Centra la ventana en la pantalla"""
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() // 2) - (self.root.winfo_width() // 2)
        y = (self.root.winfo_screenheight() // 2) - (self.root.winfo_height() // 2)
        self.root.geometry(f"+{x}+{y}")
    
    def start_move(self, event):
        self.x = event.x
        self.y = event.y
    
    def stop_move(self, event):
        self.x = None
        self.y = None
    
    def on_move(self, event):
        deltax = event.x - self.x
        deltay = event.y - self.y
        x = self.root.winfo_x() + deltax
        y = self.root.winfo_y() + deltay
        self.root.geometry(f"+{x}+{y}")
    
    def create_title_bar(self):
        # Barra de título personalizada
        self.title_bar = tk.Frame(self.main_frame, bg=self.theme_colors["title_bg"], height=30, relief="raised", bd=0)
        self.title_bar.pack(fill=tk.X, side=tk.TOP)
        self.title_bar.pack_propagate(False)
        
        # Título de la ventana
        title_label = tk.Label(self.title_bar, text="TheKeProjects Hub", 
                              bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"], 
                              font=('Arial', 10, 'bold'))
        title_label.pack(side=tk.LEFT, padx=10)
        
        # Botones de la barra de título
        button_frame = tk.Frame(self.title_bar, bg=self.theme_colors["title_bg"])
        button_frame.pack(side=tk.RIGHT, padx=5)
        
        # Botón de actualización (solo visible cuando hay actualizaciones)
        self.update_btn = tk.Button(button_frame, text="🔄", font=("Arial", 12), 
                                  command=self.check_updates_ui, bg=self.theme_colors["title_bg"], 
                                  fg=self.theme_colors["title_fg"], bd=0, relief="flat",
                                  activebackground=self.theme_colors["hover"])
        # Inicialmente oculto, se mostrará solo si hay actualizaciones
        self.update_btn.pack_forget()
        
        # Botón de audio
        self.audio_btn = tk.Button(button_frame, text="🔊", font=("Arial", 12), 
                                  command=self.show_audio_menu, bg=self.theme_colors["title_bg"], 
                                  fg=self.theme_colors["title_fg"], bd=0, relief="flat",
                                  activebackground=self.theme_colors["hover"])
        self.audio_btn.pack(side=tk.LEFT, padx=2)
        
        # Botón para cambiar tema
        self.theme_btn = tk.Button(button_frame, text="🎨", font=("Arial", 12), 
                                  command=self.show_theme_menu, bg=self.theme_colors["title_bg"], 
                                  fg=self.theme_colors["title_fg"], bd=0, relief="flat",
                                  activebackground=self.theme_colors["hover"])
        self.theme_btn.pack(side=tk.LEFT, padx=2)
        
        # Botón para cerrar
        self.close_btn = tk.Button(button_frame, text="×", font=("Arial", 16), 
                             command=self.clean_exit, bg=self.theme_colors["title_bg"], 
                             fg=self.theme_colors["title_fg"], bd=0, relief="flat",
                             activebackground="#ff0000")
        self.close_btn.pack(side=tk.LEFT, padx=2)
        
        # Configurar hover para botones
        self.close_btn.bind("<Enter>", lambda e: self.close_btn.config(bg="#ff0000", fg="white"))
        self.close_btn.bind("<Leave>", lambda e: self.close_btn.config(bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"]))
        
        self.audio_btn.bind("<Enter>", lambda e: self.audio_btn.config(bg=self.theme_colors["hover"]))
        self.audio_btn.bind("<Leave>", lambda e: self.audio_btn.config(bg=self.theme_colors["title_bg"]))
        
        self.theme_btn.bind("<Enter>", lambda e: self.theme_btn.config(bg=self.theme_colors["hover"]))
        self.theme_btn.bind("<Leave>", lambda e: self.theme_btn.config(bg=self.theme_colors["title_bg"]))
        
        self.update_btn.bind("<Enter>", lambda e: self.update_btn.config(bg=self.theme_colors["hover"]))
        self.update_btn.bind("<Leave>", lambda e: self.update_btn.config(bg=self.theme_colors["title_bg"]))
    
    def show_audio_menu(self):
        """Muestra el menú de opciones de audio"""
        menu = tk.Menu(self.root, tearoff=0, 
                      bg=self.theme_colors["entry_bg"], 
                      fg=self.theme_colors["entry_fg"])
        
        menu.add_command(label="Activar música", command=self.enable_music)
        menu.add_command(label="Desactivar música", command=self.disable_music)
        menu.add_separator()
        menu.add_command(label="Pausar/Reanudar", command=self.toggle_music)
        menu.add_command(label="Detener música", command=self.stop_music)
        menu.add_separator()
        menu.add_command(label="Control de audio...", command=self.show_volume_control)
        
        # Mostrar el menú cerca del botón
        btn_x = self.audio_btn.winfo_rootx()
        btn_y = self.audio_btn.winfo_rooty() + self.audio_btn.winfo_height()
        menu.post(btn_x, btn_y)
    
    def enable_music(self):
        self.music_enabled = True
        self.settings["music_enabled"] = True
        self.save_settings()
        self.play_theme_music()
    
    def disable_music(self):
        self.music_enabled = False
        self.settings["music_enabled"] = False
        self.save_settings()
        self.stop_music()
    
    def apply_theme(self):
        """Aplica el tema actual a todos los widgets"""
        # Actualizar frame principal
        self.main_frame.config(bg=self.theme_colors["bg_color"])
        
        # Actualizar barra de título
        self.apply_title_bar_theme()
        
        # Actualizar vistas principales
        self.update_view_theme(self.main_view)
        self.update_view_theme(self.patchnotes_view)
        
        # Actualizar barra de scroll
        self.canvas.config(bg=self.theme_colors["canvas_bg"])
        
        # Configurar estilo para la scrollbar
        style = ttk.Style()
        style.configure("TScrollbar", 
                        background=self.theme_colors["scrollbar_bg"],
                        troughcolor=self.theme_colors["scrollbar_trough"])
        self.scrollbar.configure(style="TScrollbar")
        
        # Actualizar todos los widgets en el frame desplazable
        self.update_scrollable_frame_theme()
        
        # Actualizar estado
        self.status_label.config(bg=self.theme_colors["status_bg"], fg=self.theme_colors["status_fg"])
        self.status_frame.config(bg=self.theme_colors["status_bg"])
    
    def update_scrollable_frame_theme(self):
        """Actualiza el tema de todos los widgets en el frame desplazable"""
        for app_frame in self.scrollable_frame.winfo_children():
            if isinstance(app_frame, tk.Frame):
                app_frame.config(bg=self.theme_colors["bg_color"], highlightbackground=self.theme_colors["frame_border"])
                for inner_frame in app_frame.winfo_children():
                    if isinstance(inner_frame, tk.Frame):
                        inner_frame.config(bg=self.theme_colors["bg_color"])
                        for widget in inner_frame.winfo_children():
                            if isinstance(widget, tk.Frame):  # Icon frame
                                widget.config(bg=self.theme_colors["bg_color"], highlightbackground=self.theme_colors["frame_border"])
                                for canvas in widget.winfo_children():
                                    if isinstance(canvas, tk.Canvas):
                                        canvas.config(bg=self.theme_colors["bg_color"])
                            elif isinstance(widget, tk.Frame):  # Info frame
                                widget.config(bg=self.theme_colors["bg_color"])
                                for label in widget.winfo_children():
                                    if isinstance(label, tk.Label):
                                        label.config(bg=self.theme_colors["bg_color"], fg=self.theme_colors["label_fg"])
                            elif isinstance(widget, tk.Frame):  # Button frame
                                widget.config(bg=self.theme_colors["bg_color"])
                                for btn in widget.winfo_children():
                                    if isinstance(btn, tk.Button):
                                        btn.config(bg=self.theme_colors["button_bg"], fg=self.theme_colors["button_fg"])
    
    def update_view_theme(self, view):
        """Actualiza el tema para una vista específica"""
        view.config(bg=self.theme_colors["bg_color"])
        for widget in view.winfo_children():
            if isinstance(widget, tk.Frame):
                # Frame de título
                if hasattr(widget, 'winfo_children') and widget.winfo_children():
                    first_child = widget.winfo_children()[0]
                    if isinstance(first_child, tk.Label) and "Aplicaciones Disponibles" in first_child.cget("text"):
                        widget.config(bg=self.theme_colors["title_bg"])
                        for child in widget.winfo_children():
                            if isinstance(child, tk.Label):
                                child.config(bg=self.theme_colors["title_bg"], fg=self.theme_colors["title_fg"])
                    else:
                        widget.config(bg=self.theme_colors["bg_color"])
                        for child in widget.winfo_children():
                            if isinstance(child, (tk.Label, tk.Button)):
                                child.config(bg=self.theme_colors["bg_color"], fg=self.theme_colors["label_fg"])
                            elif isinstance(child, tk.Frame):
                                child.config(bg=self.theme_colors["bg_color"])
                                for grandchild in child.winfo_children():
                                    if isinstance(grandchild, (tk.Label, tk.Button, tk.Text)):
                                        if isinstance(grandchild, tk.Text):
                                            grandchild.config(bg=self.theme_colors["entry_bg"], fg=self.theme_colors["entry_fg"],
                                                             insertbackground=self.theme_colors["label_fg"])
                                        else:
                                            grandchild.config(bg=self.theme_colors["bg_color"], fg=self.theme_colors["label_fg"])
    
    def create_main_view(self):
        self.main_view = tk.Frame(self.main_frame, bg=self.theme_colors["bg_color"])
        
        # Título
        title_frame = tk.Frame(self.main_view, bg=self.theme_colors["title_bg"], height=60)
        title_frame.pack(fill=tk.X, pady=(0, 20))
        title_frame.pack_propagate(False)
        
        title_label = tk.Label(title_frame, text="Aplicaciones Disponibles", 
                              font=('Arial', 18, 'bold'), 
                              bg=self.theme_colors["title_bg"], 
                              fg=self.theme_colors["title_fg"])
        title_label.pack(expand=True)
        
        # Frame para apps con scrollbar
        self.create_scrollable_frame()
        
        self.create_app_buttons()
        self.load_versions_info()
        
        # Frame estado (solo texto, sin barra de progreso)
        self.status_frame = tk.Frame(self.main_view, bg=self.theme_colors["status_bg"])
        self.status_frame.pack(fill=tk.X, pady=10, padx=20)
        
        self.status_var = tk.StringVar(value="Selecciona una aplicación para instalar")
        self.status_label = tk.Label(self.status_frame, textvariable=self.status_var, 
                                    bg=self.theme_colors["status_bg"], 
                                    fg=self.theme_colors["status_fg"],
                                    font=('Arial', 10))
        self.status_label.pack(side=tk.LEFT)
    
    def create_scrollable_frame(self):
        container = tk.Frame(self.main_view, bg=self.theme_colors["bg_color"])
        container.pack(fill=tk.BOTH, expand=True, padx=20)
        
        self.canvas = tk.Canvas(container, borderwidth=0, bg=self.theme_colors["canvas_bg"], highlightthickness=0)
        
        # Configurar estilo para la scrollbar
        style = ttk.Style()
        style.configure("TScrollbar", 
                        background=self.theme_colors["scrollbar_bg"],
                        troughcolor=self.theme_colors["scrollbar_trough"])
        
        self.scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.canvas.yview, style="TScrollbar")
        self.scrollable_frame = tk.Frame(self.canvas, bg=self.theme_colors["bg_color"])
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        self.canvas.bind("<Enter>", self._bind_mousewheel)
        self.canvas.bind("<Leave>", self._unbind_mousewheel)
        
        def configure_canvas(event):
            self.canvas.itemconfig("all", width=event.width)
        self.canvas.bind("<Configure>", configure_canvas)
    
    def _bind_mousewheel(self, event):
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
    
    def _unbind_mousewheel(self, event):
        self.canvas.unbind_all("<MouseWheel>")
    
    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
    
    def create_app_buttons(self):
        for app in self.apps:
            frame = tk.Frame(self.scrollable_frame, bg=self.theme_colors["bg_color"], 
                            relief="solid", bd=1, highlightbackground=self.theme_colors["frame_border"])
            frame.pack(fill=tk.X, padx=5, pady=10)
            
            inner_frame = tk.Frame(frame, bg=self.theme_colors["bg_color"])
            inner_frame.pack(fill=tk.X, padx=10, pady=10)
            
            # Icono
            icon_frame = tk.Frame(inner_frame, width=64, height=64, bg=self.theme_colors["bg_color"], 
                                 relief="solid", bd=1, highlightbackground=self.theme_colors["frame_border"])
            icon_frame.pack(side=tk.LEFT, padx=(0, 15))
            icon_frame.pack_propagate(False)
            
            icon_canvas = tk.Canvas(icon_frame, width=64, height=64, bg=self.theme_colors["bg_color"], highlightthickness=0)
            icon_canvas.pack(fill=tk.BOTH, expand=True)
            
            # Solo el icono instala directamente
            icon_canvas.bind("<Button-1>", lambda e, a=app: self.install_app(a))
            icon_canvas.bind("<Enter>", lambda e, c=icon_canvas, f=icon_frame: self.on_icon_enter(e, c, f))
            icon_canvas.bind("<Leave>", lambda e, c=icon_canvas, f=icon_frame: self.on_icon_leave(e, c, f))
            
            self.load_image(app['icon_url'], icon_canvas, app)
            
            info_frame = tk.Frame(inner_frame, bg=self.theme_colors["bg_color"])
            info_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
            
            name_label = tk.Label(info_frame, text=app['name'], 
                                 font=('Arial', 14, 'bold'), 
                                 bg=self.theme_colors["bg_color"], 
                                 fg=self.theme_colors["label_fg"])
            name_label.pack(anchor=tk.W)
            
            version_var = tk.StringVar(value=app['version'])
            version_label = tk.Label(info_frame, textvariable=version_var, 
                                    font=('Arial', 10), 
                                    bg=self.theme_colors["bg_color"], 
                                    fg=self.theme_colors["label_fg"])
            version_label.pack(anchor=tk.W)
            app['version_widget'] = version_var
            
            changelog_var = tk.StringVar(value=app['changelog'])
            changelog_label = tk.Label(info_frame, textvariable=changelog_var, 
                                      font=('Arial', 9), 
                                      bg=self.theme_colors["bg_color"], 
                                      fg=self.theme_colors["label_fg"], 
                                      wraplength=600, justify=tk.LEFT)
            changelog_label.pack(anchor=tk.W)
            app['changelog_widget'] = changelog_var
            
            button_frame = tk.Frame(inner_frame, bg=self.theme_colors["bg_color"])
            button_frame.pack(side=tk.RIGHT, padx=(10, 0))
            
            repo_btn = tk.Button(
                button_frame, text="📂", font=("Arial", 14),
                command=lambda r=app['repo']: self.open_repo(f"https://github.com/{r}"),
                width=3, height=1, relief="solid", bd=1, 
                bg=self.theme_colors["button_bg"], 
                fg=self.theme_colors["button_fg"]
            )
            repo_btn.pack(anchor=tk.E, pady=2, fill=tk.X)
            
            notes_btn = tk.Button(
                button_frame, text="📝", font=("Arial", 14),
                command=lambda a=app: self.show_patchnotes(a),
                width=3, height=1, relief="solid", bd=1, 
                bg=self.theme_colors["button_bg"], 
                fg=self.theme_colors["button_fg"]
            )
            notes_btn.pack(anchor=tk.E, pady=2, fill=tk.X)
    
    def on_enter(self, event, frame):
        frame.configure(bg=self.theme_colors["hover"])
        for child in frame.winfo_children():
            if isinstance(child, tk.Frame):
                child.configure(bg=self.theme_colors["hover"])
                for grandchild in child.winfo_children():
                    if isinstance(grandchild, (tk.Frame, tk.Label)):
                        grandchild.configure(bg=self.theme_colors["hover"])
    
    def on_leave(self, event, frame):
        frame.configure(bg=self.theme_colors["bg_color"])
        for child in frame.winfo_children():
            if isinstance(child, tk.Frame):
                child.configure(bg=self.theme_colors["bg_color"])
                for grandchild in child.winfo_children():
                    if isinstance(grandchild, (tk.Frame, tk.Label)):
                        grandchild.configure(bg=self.theme_colors["bg_color"])
    
    def on_icon_enter(self, event, canvas, frame):
        canvas.configure(cursor="hand2")
        canvas.config(bg=self.theme_colors["icon_hover"])
        frame.config(bg=self.theme_colors["icon_hover"], relief="solid", bd=3, highlightbackground="#0078d7")
    
    def on_icon_leave(self, event, canvas, frame):
        canvas.configure(cursor="")
        canvas.config(bg=self.theme_colors["bg_color"])
        frame.config(bg=self.theme_colors["bg_color"], relief="solid", bd=1, highlightbackground=self.theme_colors["frame_border"])
    
    def load_image(self, url, canvas, app):
        def load():
            try:
                response = requests.get(url, timeout=10)
                image_data = response.content
                image = Image.open(BytesIO(image_data)).resize((64, 64), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(image)
                self.root.after(0, self.set_image, canvas, photo, app)
            except:
                default_img = Image.new('RGB', (64, 64), color='lightgray')
                photo = ImageTk.PhotoImage(default_img)
                self.root.after(0, self.set_image, canvas, photo, app)
        threading.Thread(target=load, daemon=True).start()
    
    def set_image(self, canvas, photo, app):
        canvas.image = photo
        canvas.create_image(32, 32, image=photo)
        self.create_tooltip(canvas, f"Haz clic para instalar {app['name']}")
    
    def create_tooltip(self, widget, text):
        def on_enter(event):
            tooltip = tk.Toplevel(widget)
            tooltip.overrideredirect(True)
            tooltip.geometry(f"+{event.x_root+10}+{event.y_root+10}")
            tooltip.wm_attributes('-topmost', True)
            label = tk.Label(tooltip, text=text, background="yellow", 
                            relief="solid", borderwidth=1, 
                            fg="black", font=('Arial', 10))
            label.pack()
            widget.tooltip = tooltip
        
        def on_leave(event):
            if hasattr(widget, 'tooltip'):
                widget.tooltip.destroy()
                delattr(widget, 'tooltip')
        
        widget.bind("<Enter>", on_enter)
        widget.bind("<Leave>", on_leave)
    
    def load_versions_info(self):
        def load_info():
            for app in self.apps:
                try:
                    # Obtener versión desde archivo raw
                    version_response = requests.get(app['version_url'], timeout=10)
                    if version_response.status_code == 200:
                        version = version_response.text.strip()
                        app['version'] = f"Versión: {version}"
                    else:
                        app['version'] = "Versión: No disponible"
                    
                    # Obtener changelog desde archivo raw
                    changelog_response = requests.get(app['changelog_url'], timeout=10)
                    if changelog_response.status_code == 200:
                        changelog = changelog_response.text.strip()
                        # Filtrar solo líneas que comienzan con -
                        filtered_lines = [line for line in changelog.splitlines() if line.strip().startswith("-")]
                        app['changelog'] = "\n".join(filtered_lines) if filtered_lines else "No hay notas de versión relevantes."
                    else:
                        app['changelog'] = "No se pudo obtener el changelog"
                    
                    # Construir URL de descarga basada en la versión
                    if version_response.status_code == 200:
                        version_tag = version
                        app['release_url'] = f"https://github.com/{app['repo']}/releases/download/{version_tag}/{app['filename']}"
                    else:
                        app['release_url'] = None
                    
                    self.root.after(0, self.update_app_info, app)
                except Exception as e:
                    app['version'] = "Versión: Error"
                    app['changelog'] = f"Excepción: {str(e)}"
                    app['release_url'] = None
                    self.root.after(0, self.update_app_info, app)
        threading.Thread(target=load_info, daemon=True).start()
    
    def update_app_info(self, app):
        if 'version_widget' in app:
            app['version_widget'].set(app['version'])
        if 'changelog_widget' in app:
            changelog = app['changelog']
            if len(changelog) > 150:
                changelog = changelog[:147] + "..."
            app['changelog_widget'].set(changelog)
    
    def open_repo(self, url):
        webbrowser.open_new_tab(url)
    
    def show_patchnotes(self, app):
        self.current_app = app
        try:
            # Obtener patchnotes desde archivo raw
            patchnotes_url = f"https://raw.githubusercontent.com/{app['repo']}/main/patchnotes.txt"
            response = requests.get(patchnotes_url, timeout=10)
            if response.status_code == 200:
                content = response.text.strip()
                if not content:
                    content = "No se encontraron entradas relevantes en patchnotes."
            else:
                content = "No se encontraron notas de parche."
        except Exception as e:
            content = f"Error cargando notas: {e}"
        
        self.patchnotes_text.config(state=tk.NORMAL)
        self.patchnotes_text.delete(1.0, tk.END)
        self.patchnotes_text.insert(tk.END, content)
        self.patchnotes_text.config(state=tk.DISABLED)
        
        self.show_patchnotes_view()
    
    def create_patchnotes_view(self):
        self.patchnotes_view = tk.Frame(self.main_frame, bg=self.theme_colors["bg_color"])
        
        title_frame = tk.Frame(self.patchnotes_view, bg=self.theme_colors["title_bg"], height=60)
        title_frame.pack(fill=tk.X, pady=(0, 20))
        title_frame.pack_propagate(False)
        
        self.patchnotes_title = tk.Label(title_frame, text="Notas del Parche", 
                                        font=('Arial', 18, 'bold'), 
                                        bg=self.theme_colors["title_bg"], 
                                        fg=self.theme_colors["title_fg"])
        self.patchnotes_title.pack(expand=True)
        
        text_frame = tk.Frame(self.patchnotes_view, bg=self.theme_colors["bg_color"])
        text_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        self.patchnotes_text = tk.Text(text_frame, wrap=tk.WORD, font=('Arial', 11),
                                      bg=self.theme_colors["entry_bg"], 
                                      fg=self.theme_colors["entry_fg"],
                                      insertbackground=self.theme_colors["label_fg"])  # Color del cursor
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=self.patchnotes_text.yview)
        self.patchnotes_text.configure(yscrollcommand=scrollbar.set)
        
        self.patchnotes_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        button_frame = tk.Frame(self.patchnotes_view, bg=self.theme_colors["bg_color"])
        button_frame.pack(fill=tk.X, pady=10, padx=20)
        
        back_btn = tk.Button(button_frame, text="Volver a Aplicaciones", 
                            font=('Arial', 12), command=self.show_main_view,
                            height=2, bg=self.theme_colors["button_bg"], 
                            fg=self.theme_colors["button_fg"])
        back_btn.pack(fill=tk.X)
    
    def show_main_view(self):
        self.current_view = "main"
        self.patchnotes_view.pack_forget()
        self.main_view.pack(fill=tk.BOTH, expand=True)
    
    def show_patchnotes_view(self):
        self.current_view = "patchnotes"
        self.main_view.pack_forget()
        self.patchnotes_view.pack(fill=tk.BOTH, expand=True)
        
        if self.current_app:
            self.patchnotes_title.config(text=f"Notas del Parche - {self.current_app['name']}")
    
    def install_app(self, app):
        if not app.get('release_url'):
            messagebox.showerror("Error", f"No se pudo encontrar el enlace de descarga para {app['name']}")
            return
            
        self.update_status(f"Instalando {app['name']}...")
        
        def install_thread():
            try:
                # Verificar si la URL de descarga es válida
                try:
                    head_response = requests.head(app['release_url'], timeout=10, allow_redirects=True)
                    if head_response.status_code != 200:
                        raise Exception(f"El archivo no está disponible. Código: {head_response.status_code}")
                except Exception as e:
                    raise Exception(f"No se pudo acceder al archivo: {str(e)}")
                
                response = requests.get(app['release_url'], stream=True, timeout=30)
                if response.status_code != 200:
                    raise Exception(f"No se pudo descargar la aplicación. Código: {response.status_code}")
                
                temp_dir = os.path.join(os.environ['TEMP'], 'GitHubAppInstaller')
                os.makedirs(temp_dir, exist_ok=True)
                installer_path = os.path.join(temp_dir, app['filename'])
                
                with open(installer_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                
                # Mostrar mensaje antes de instalar
                self.root.after(0, lambda: messagebox.showinfo(
                    "Instalación iniciada", 
                    f"El instalador de {app['name']} se ha descargado.\nSigue las instrucciones en la ventana de instalación."
                ))
                
                # Esperar 3 segundos antes de abrir el instalador
                time.sleep(3)
                
                subprocess.Popen([installer_path], shell=True)
                
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror(
                    "Error de instalación", 
                    f"No se pudo instalar {app['name']}: {str(e)}"
                ))
            finally:
                self.root.after(0, lambda: self.update_status("Selecciona una aplicación para instalar"))
        
        threading.Thread(target=install_thread, daemon=True).start()

    def update_status(self, message):
        self.status_var.set(message)

if __name__ == "__main__":
    root = tk.Tk()
    app = GitHubAppInstaller(root)
    root.mainloop()